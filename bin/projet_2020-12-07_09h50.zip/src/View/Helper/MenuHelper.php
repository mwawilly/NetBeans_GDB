<?php

namespace App\View\Helper;

use Cake\View\Helper;

class MenuHelper extends Helper {

    public $helpers = ['Html'];
    
    public function listMethods($class) {
        $array1 = get_class_methods($class);
        if ($parent_class = get_parent_class($class)) {
            $array2 = get_class_methods($parent_class);
            $array3 = array_diff($array1, $array2);
        } else {
            $array3 = $array1;
        }
        $parts = explode(DS, $class);   
        $ctrl = str_replace("Controller", "", end($parts));
        foreach ($array3 as $method_name) {
            echo '<li>'.$this->Html->link($method_name, ['controller' => $ctrl, 'action' => $method_name]).'</li>'.PHP_EOL;
        }
    }

}
