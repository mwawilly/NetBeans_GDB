<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\CompetencesTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\CompetencesTable Test Case
 */
class CompetencesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\CompetencesTable
     */
    public $Competences;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.Competences',
        'app.Etudiants'
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Competences') ? [] : ['className' => CompetencesTable::class];
        $this->Competences = TableRegistry::getTableLocator()->get('Competences', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Competences);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
