<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Competences Controller
 *
 * @property \App\Model\Table\CompetencesTable $Competences
 *
 * @method \App\Model\Entity\Competence[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CompetencesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $competences = $this->paginate($this->Competences);

        $this->set(compact('competences'));
    }

    /**
     * View method
     *
     * @param string|null $id Competence id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $competence = $this->Competences->get($id, [
            'contain' => ['Etudiants']
        ]);

        $this->set('competence', $competence);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $competence = $this->Competences->newEntity();
        if ($this->request->is('post')) {
            $competence = $this->Competences->patchEntity($competence, $this->request->getData());
            if ($this->Competences->save($competence)) {
                $this->Flash->success(__('The competence has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The competence could not be saved. Please, try again.'));
        }
        $etudiants = $this->Competences->Etudiants->find('list', ['limit' => 200]);
        $this->set(compact('competence', 'etudiants'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Competence id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $competence = $this->Competences->get($id, [
            'contain' => ['Etudiants']
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $competence = $this->Competences->patchEntity($competence, $this->request->getData());
            if ($this->Competences->save($competence)) {
                $this->Flash->success(__('The competence has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The competence could not be saved. Please, try again.'));
        }
        $etudiants = $this->Competences->Etudiants->find('list', ['limit' => 200]);
        $this->set(compact('competence', 'etudiants'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Competence id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $competence = $this->Competences->get($id);
        if ($this->Competences->delete($competence)) {
            $this->Flash->success(__('The competence has been deleted.'));
        } else {
            $this->Flash->error(__('The competence could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
