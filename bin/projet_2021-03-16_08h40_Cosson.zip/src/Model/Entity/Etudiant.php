<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Etudiant Entity
 *
 * @property int $id
 * @property string|null $nom
 * @property string|null $prenom
 * @property int|null $promotion_id
 * @property int|null $bac_id
 *
 * @property \App\Model\Entity\Promotion $promotion
 * @property \App\Model\Entity\Bac $bac
 * @property \App\Model\Entity\Competence[] $competences
 */
class Etudiant extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'nom' => true,
        'prenom' => true,
        'promotion_id' => true,
        'bac_id' => true,
        'promotion' => true,
        'bac' => true,
        'competences' => true
    ];
}
