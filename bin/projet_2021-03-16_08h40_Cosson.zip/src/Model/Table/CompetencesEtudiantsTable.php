<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * CompetencesEtudiants Model
 *
 * @property \App\Model\Table\CompetencesTable&\Cake\ORM\Association\BelongsTo $Competences
 * @property \App\Model\Table\EtudiantsTable&\Cake\ORM\Association\BelongsTo $Etudiants
 *
 * @method \App\Model\Entity\CompetencesEtudiant get($primaryKey, $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\CompetencesEtudiant findOrCreate($search, callable $callback = null, $options = [])
 */
class CompetencesEtudiantsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('competences_etudiants');
        $this->setDisplayField('id');
        $this->setPrimaryKey('id');

        $this->belongsTo('Competences', [
            'foreignKey' => 'competence_id'
        ]);
        $this->belongsTo('Etudiants', [
            'foreignKey' => 'etudiant_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->existsIn(['competence_id'], 'Competences'));
        $rules->add($rules->existsIn(['etudiant_id'], 'Etudiants'));

        return $rules;
    }
}
