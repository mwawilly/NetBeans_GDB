<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Bacs Model
 *
 * @property \App\Model\Table\EtudiantsTable&\Cake\ORM\Association\HasMany $Etudiants
 *
 * @method \App\Model\Entity\Bac get($primaryKey, $options = [])
 * @method \App\Model\Entity\Bac newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Bac[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Bac|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Bac saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Bac patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Bac[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Bac findOrCreate($search, callable $callback = null, $options = [])
 */
class BacsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('bacs');
        $this->setDisplayField('serie');
        $this->setPrimaryKey('id');

        $this->hasMany('Etudiants', [
            'foreignKey' => 'bac_id'
        ]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id')
            ->allowEmptyString('id', null, 'create');

        $validator
            ->scalar('serie')
            ->maxLength('serie', 50)
            ->allowEmptyString('serie');

        return $validator;
    }
}
