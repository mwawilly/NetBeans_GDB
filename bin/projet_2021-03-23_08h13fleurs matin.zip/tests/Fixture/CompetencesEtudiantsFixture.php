<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * CompetencesEtudiantsFixture
 */
class CompetencesEtudiantsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id' => ['type' => 'integer', 'length' => 10, 'autoIncrement' => true, 'null' => false, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null],
        'competence_id' => ['type' => 'integer', 'length' => 10, 'null' => true, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null, 'autoIncrement' => null],
        'etudiant_id' => ['type' => 'integer', 'length' => 10, 'null' => true, 'default' => null, 'precision' => null, 'comment' => null, 'unsigned' => null, 'autoIncrement' => null],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id'], 'length' => []],
            'IX_competences_etudiants' => ['type' => 'unique', 'columns' => ['competence_id', 'etudiant_id'], 'length' => []],
            'FK_competences_etudiants_etudiants' => ['type' => 'foreign', 'columns' => ['etudiant_id'], 'references' => ['etudiants', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
            'FK_competences_etudiants_competences' => ['type' => 'foreign', 'columns' => ['competence_id'], 'references' => ['competences', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id' => 1,
                'competence_id' => 1,
                'etudiant_id' => 1
            ],
        ];
        parent::init();
    }
}
