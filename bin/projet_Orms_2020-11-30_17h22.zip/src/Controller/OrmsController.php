<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class OrmsController extends AppController {

    public function index() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        
        $query = $etudiants->find('all'); //entities
				
        $this->set('query', $query);
        $this->render('debug');
    }
    public function nomPrenom(){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
           
        $query = $etudiants->find('all'); //entities
        $query = $query->select(['nom', 'prenom']);
        
        $this->set('query', $query);
        $this->render('debug');
    }
    
    public function sisr2019(){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
           
        $query = $etudiants->find('all'); //entities
        $query = $query->where(['specialite'=> 'SISR', 'promo'=>2019]);
        
        $this->set('query', $query);
        $this->render('debug');
    }
    
    public function EtudiantSerieBac(){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        $etudiants ->belongsTo('bacs'); //table
        $query = $etudiants ->find('all');
        $query = $query ->contain('bacs'); //entities
        $query = $query -> select(['nom','prenom','bacs.serie']);
        $this->set('query', $query);
    }
    
    public function EtudiantAvecCompetences(){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        $etudiants ->belongsToMany('competences'); //table
        $query = $etudiants->find('all');
        $query = $query ->contain('competences'); //entities
        
        $this->set('query', $query);
    }
    
    public function NombreEtudiantSerieBac(){
        $etudiants = TableRegistry::getTableLocator()->get('Bacs'); //table
        $etudiants ->hasMany('Etudiants'); //table
        
        $query = $etudiants->find('all');
        $query = $query ->matching('Etudiants'); //entities
        $query = $query ->select(['serie', 'nbEtudiants' => $query->func()->count("*")]);
        $query = $query ->group(['serie']);
        
        $this->set('query', $query);
        $this->render('debug');
    }
	
}