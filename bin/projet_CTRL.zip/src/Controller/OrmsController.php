<?php

namespace App\Controller;

use App\Controller\AppController;
use Cake\ORM\TableRegistry;

class OrmsController extends AppController {

    public function index() {
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table

        $query = $etudiants->find('all'); //entities

        $this->set('query', $query);
        $this->render('debug');
    }
    public function etudiants($nameFilter =""){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        
        $query = $etudiants->find('all'); //entities
        $query = $query->select(['nom','prenom']); //entities
        $query = $query->where(['nom LIKE'=> $nameFilter.'%']); //entities

        $this->set('query', $query);
    }
    
    public function competences()
    {
        $competence = TableRegistry::getTableLocator()->get('Competences');
        $query = $competence->find('all');
        $query = $query->select(['code','libelle']);
        $this->set('query',$query);
    }
    
    
    public function etudiantSerieBac(){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        
        $etudiants->belongsTo('bacs');

        $query = $etudiants->find('all'); //entities
        $query = $query->contain('bacs');
        $query = $query->select(['nom', 'prenom', 'bacs.serie']);

        $this->set('query', $query);
        $this->render('etudiant_serie_bac');
    }
    
    public function etudiantTableauSynthese(){
        $etudiants = TableRegistry::getTableLocator()->get('Etudiants'); //table
        
        $etudiants->belongsToMany('competences');

        $query = $etudiants->find('all'); //entities
        $query = $query->contain(['competences']);

        $this->set('query', $query);
    }
    
    public function bacNbEtudiants(){
        $etudiants = TableRegistry::getTableLocator()->get('bacs'); //table
        
        $etudiants->hasMany('etudiants');

        $query = $etudiants->find('all'); //entities
        $query = $query->matching('etudiants');
        $query = $query->select(['serie', 'nbEtudiants' => $query->func()->count('*')]);
        $query = $query->group('serie');

        $this->set('query', $query);
    }
     
}

?>